namespace Http
{
    enum MethodType
    {
        GET,
        POST
    }
}